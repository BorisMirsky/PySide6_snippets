# This Python file uses the following encoding: utf-8
from dataclasses import dataclass


class RailwayMarkerLocation(Enum):
    Left = -1
    Middle = 0
    Right = 1
class RailwayMarkerType(Enum):
    UNDEFINED = 0,
    # Rfid tag
    RfidTagLeft = 10,
    RfidTagMiddle = 11,
    RfidTagRight = 12,
    # Contact network
    ContactNetworkLeft = 20,
    ContactNetworkRight = 21,
    # Platform
    PlatformLeftStart = 30,
    PlatformLeftEnd = 31,
    PlatformRightStart = 32,
    PlatformRightEnd = 33,
    # Tunnel
    TunnelStart = 40,
    TunnelEnd = 41,
    # Arrow
    ArrowPointerLeft = 50,
    ArrowCrossLeft = 51,
    ArrowPointerRight = 52,
    ArrowCrossRight = 53,
    # Additional
    StationaryBrakeStop = 100,
    CrossPipe = 101,
    MiscellaneousLeft = 200,
    MiscellaneousMiddle = 201,
    MiscellaneousRight = 202


@dataclass(frozen = True, slots = True)
class RailwayMarker:
    type: RailwayMarkerType
    title: str




# @dataclass(frozen = True)
# class AbstractRailwayMarker:
#     def __str__(self) ->str:
#         return 'Unidifined railway marker'

# @dataclass(frozen = True)
# class RfidTag(AbstractRailwayMarker):
#     tag_id: bytes
#     def __str__(self) ->str:
#         return self.tag_id.decode('utf-8')

# @dataclass(frozen = True)
# class UserTag(AbstractRailwayMarker):
#     name: str
#     def __str__(self) ->str:
#         return self.name
