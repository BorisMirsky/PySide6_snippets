# This Python file uses the following encoding: utf-8
from dataclasses import dataclass
from enum import Enum
import pandas

class BaseRail(Enum):
    Left = 0
    Right = 1
class MovingDirection(Enum):
    Forward = 1
    Backward = 2
    def multiplier(self) ->int:
        return 1 if (self == self.Forward) else -1
class PicketDirection(Enum):
    Forward = 1
    Backward = 2
    def multiplier(self) ->int:
        return 1 if (self == self.Forward) else -1




@dataclass(frozen = True, slots = True)
class LocationVector1D:
    meters: float
@dataclass(frozen=True)
class SteppedData:
    data: pandas.DataFrame
    step: LocationVector1D


